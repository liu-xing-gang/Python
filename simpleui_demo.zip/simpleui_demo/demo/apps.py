from django.apps import AppConfig


class DemoConfig(AppConfig):
    name = 'demo'
    verbose_name = '综合管理'

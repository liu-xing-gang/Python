# 这个例子可以教大家自己扩展django的组件

需要在settings.py中加入
